package main

import (
	"errors"
	"fmt"
	"math/rand"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
)

// Product represents an inventory item
type Product struct {
	ID       int     `json:"id"`
	Name     string  `json:"name"`
	Price    float64 `json:"price"`
	Quantity int     `json:"quantity"`
	Category string  `json:"category"`
}

// --- Product Methods ---

func (p *Product) UpdatePrice(newPrice float64) {
	p.Price = newPrice
}

func (p *Product) Sell(quantity int) error {
	if p.Quantity < quantity {
		return errors.New("not enough stock available")
	}
	p.Quantity -= quantity
	return nil
}

func (p *Product) Restock(quantity int) {
	p.Quantity += quantity
}

func (p *Product) Display() string {
	return fmt.Sprintf("ID: %d, Name: %s, Price: %.2f, Quantity: %d, Category: %s",
		p.ID, p.Name, p.Price, p.Quantity, p.Category)
}

// --- Product Storage Interface ---

type ProductStorage interface {
	Save(p Product) error
	GetByID(id int) (*Product, error)
	Delete(id int) error
	List() []Product
}

// --- Memory Storage Implementation ---

type MemoryStorage struct {
	products map[int]Product
}

func NewMemoryStorage() *MemoryStorage {
	return &MemoryStorage{products: make(map[int]Product)}
}

func (m *MemoryStorage) Save(p Product) error {
	if _, exists := m.products[p.ID]; exists {
		return errors.New("product with this ID already exists")
	}
	m.products[p.ID] = p
	return nil
}

func (m *MemoryStorage) GetByID(id int) (*Product, error) {
	p, exists := m.products[id]
	if !exists {
		return nil, errors.New("product not found")
	}
	return &p, nil
}

func (m *MemoryStorage) Delete(id int) error {
	if _, exists := m.products[id]; !exists {
		return errors.New("product not found")
	}
	delete(m.products, id)
	return nil
}

func (m *MemoryStorage) List() []Product {
	var result []Product
	for _, p := range m.products {
		result = append(result, p)
	}
	return result
}

// --- Inventory Struct using Storage ---

type Inventory struct {
	storage ProductStorage
}

func NewInventory(storage ProductStorage) *Inventory {
	return &Inventory{storage: storage}
}

func (inv *Inventory) AddProduct(p Product) error {
	return inv.storage.Save(p)
}

func (inv *Inventory) RemoveProduct(id int) error {
	return inv.storage.Delete(id)
}

func (inv *Inventory) FindProductByName(name string) (*Product, error) {
	for _, p := range inv.storage.List() {
		if p.Name == name {
			return &p, nil
		}
	}
	return nil, errors.New("product not found")
}

func (inv *Inventory) ListByCategory(category string) []Product {
	var result []Product
	for _, p := range inv.storage.List() {
		if p.Category == category {
			result = append(result, p)
		}
	}
	return result
}

func (inv *Inventory) TotalValue() float64 {
	var total float64
	for _, p := range inv.storage.List() {
		total += p.Price * float64(p.Quantity)
	}
	return total
}

// --- Simulated External API ---

type ExternalAPI struct {
	BaseURL string
}

func (api *ExternalAPI) FetchProductDetails(id int) (*Product, error) {
	time.Sleep(time.Duration(rand.Intn(3)) * time.Second)
	if rand.Float32() < 0.1 {
		return nil, errors.New("external API error")
	}
	return &Product{
		ID:       id,
		Name:     "Sample Product",
		Price:    19.99,
		Quantity: 50,
		Category: "General",
	}, nil
}

// --- REST Handlers ---

func setupRouter(inv *Inventory) *gin.Engine {
	r := gin.Default()

	r.POST("/product", func(c *gin.Context) {
		var newProduct Product
		if err := c.ShouldBindJSON(&newProduct); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid product data"})
			return
		}
		if err := inv.AddProduct(newProduct); err != nil {
			c.JSON(http.StatusConflict, gin.H{"error": err.Error()})
			return
		}
		c.JSON(http.StatusCreated, gin.H{"message": "product added"})
	})

	r.GET("/products", func(c *gin.Context) {
		category := c.Query("category")
		c.JSON(http.StatusOK, inv.ListByCategory(category))
	})

	r.GET("/total_value", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"total_value": inv.TotalValue()})
	})

	return r
}

// --- Main Entry ---

func main() {
	storage := NewMemoryStorage()
	inventory := NewInventory(storage)

	router := setupRouter(inventory)
	router.Run(":8081")
}
